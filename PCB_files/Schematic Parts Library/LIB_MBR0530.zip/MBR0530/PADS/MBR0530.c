*PADS-LIBRARY-SCH-DECALS-V9*

MBR0530           32000 32000 100 10 100 10 4 2 0 2 24
TIMESTAMP 2020.10.26.07.08.31
"Default Font"
"Default Font"
450   200   0 8 100 10 "Default Font"
REF-DES
450   100   0 8 100 10 "Default Font"
PART-TYPE
300   -150  0 12 100 10 "Default Font"
*
300   -250  0 12 100 10 "Default Font"
*
COPCLS 4 10 0 -1
200   0    
400   100  
400   -100 
200   0    
OPEN   2 10 0 -1
200   100  
200   -100 
T0     0     0 0 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T600   0     0 2 0     10    0 0 0     -10   0 32 PIN
P-520  0     0 2 -80   0     0 2 0

*END*